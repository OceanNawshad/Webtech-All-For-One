<?php
	function sanitize_input($data)
	{
		$data=trim($data);
		$data=stripslashes($data);
		$data=htmlspecialchars($data);
		return $data;
		
	}
	session_start();
	
	if(isset($_POST['save&Next']))
	{
		$_SESSION['paymenttype']=sanitize_input($_POST['paymenttype']);
		$_SESSION['currency']=sanitize_input($_POST['currency']);
		$_SESSION['amount']=sanitize_input($_POST['amount']);
		$_SESSION['paymentdate']=sanitize_input($_POST['paymentdate']);
		$_SESSION['receiptno']=sanitize_input($_POST['receiptno']);
		$_SESSION['bank']=sanitize_input($_POST['bank']);
		$_SESSION['branch']=sanitize_input($_POST['branch']);
		
		
		
	
		
		
	}
	else
	{
		header("location:index.php");
	}
 
	
?>

<?php
	$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
		$txt0="Passport Application Information";
		$txt1 = "\nApplying In:".$_SESSION['country'];
		$txt2 = "\n passporttype:".$_SESSION['passporttype'];
		$txt3 = "\nDelivery Type:".$_SESSION['deliveryType'];
		$txt4 = "\nDate of Birth:".$_SESSION['dateofbirth'];
		$txt5 = "\nGender:".$_SESSION['gender'];
		$txt6 = "\nBirth Id No:".$_SESSION['birthIdNo'];
		$txt7 = "\nNational Id No:".$_SESSION['nationalIdNo'];
		$txt8 = "\ntaxIdNo:".$_SESSION['taxIdNo'];
		$txt9 = "\nHeight:".$_SESSION['cm'];
		$txt10 = "\nHeight:".$_SESSION['inch'];
		$txt11= "\nReligion:".$_SESSION['religion'];
		$txt12 = "\nEmail:".$_SESSION['email'];
		$txt13="\n\n\nPersonalInformation";
		$txt14 = "\nName of Applicant:".$_SESSION['nameOfApplicant'];
		$txt15 = "\nFirst Name:".$_SESSION['givenName'];
		$txt16 = "\nLast Name:".$_SESSION['surname'];
		$txt17 = "\nFather's Name:".$_SESSION['fathersName'];
		$txt18 = "\nFather's Nationality:".$_SESSION['fathersnationality'];
		$txt19 = "\nFather's Profession:".$_SESSION['fathersprofession'];
		$txt20 = "\nMother's Name:".$_SESSION['mothersName'];
		$txt21 = "\nMother's Nationality:".$_SESSION['mothersnationality'];
		$txt22 = "\nMother's Profession:".$_SESSION['mothersprofession'];
		$txt23 = "\nSpouse's Name:".$_SESSION['spousesName'];
		$txt24 = "\nSpouse's Nationality:".$_SESSION['spousesNationality'];
		$txt25 = "\nSopuse's Profession:".$_SESSION['spousesProfession'];
		$txt26 = "\nMarital Status:".$_SESSION['maritalStatus'];
		$txt27 = "\nApplicant's Profession:".$_SESSION['applicantsProfession'];
		$txt28 = "\ncountryOfBirth:".$_SESSION['countryOfBirth'];
		$txt29 = "\nbirthdistrict:".$_SESSION['birthdistrict'];
		
		$txt30="\n\n\n Citizenship Status";
		$txt31 = "\nNationality:".$_SESSION['nationality'];
		$txt32 = "\nCitizenship Status:".$_SESSION['citizenshipstatus'];
		$txt33 = "\nDual Citizenship:".$_SESSION['dualCitizenship'];
		
		
		$txt34="\n\n\n Present Address";
		$txt35 = "\nvillage/house:".$_SESSION['village/house'];
		$txx36 = "\nroad/block/sector:".$_SESSION['road/block/sector'];
		$txt37 = "\ndistrict:".$_SESSION['district'];
		$txt38 = "\nPolice Station:".$_SESSION['policeStation'];
		$txt39 = "\nPost Office:".$_SESSION['postOffice'];
		
		$txt40="\n\n\n Permanent Address";
		$txt41 = "\nvillage/house:".$_SESSION['village/house'];
		$txt42 = "\nRoad/Block/Sector:".$_SESSION['proad/block/sector'];
		$txt43 = "\ndistrict:".$_SESSION['district'];
		$txt44 = "\nPloice Station:".$_SESSION['permanentpoliceStation'];
		$txt45 = "\nPost Office:".$_SESSION['permanentpostoffice'];
		
		$txt46="\n\n\n Applicant Contact Information";
		$txt47 = "\nOffice No:".$_SESSION['officeno'];
		$txt48 = "\nResidence No:".$_SESSION['residence'];
		$txt49 = "\nMobile No:".$_SESSION['mobileno'];
		
		$txt50="\n\n\n Old Passport Information";
		$txt51 = "\nPassport No:".$_SESSION['passportno'];
		$txt52 = "\nPlace of Issue:".$_SESSION['placeofissue'];
		$txt53= "\nDate of Issue:".$_SESSION['dateofissue'];
		$txt54 = "\nReissue Reason:".$_SESSION['reissuereason'];
		
		$txt55="\n\n\nApplicant Contact Information";
		$txt56 = "\nName:".$_SESSION['name'];
		$txt57 = "\nCountry:".$_SESSION['country'];
		$txt58 = "\nvillage/house:".$_SESSION['village/house'];
		$txt59 = "\nroad/block/sector:".$_SESSION['road/block/sector'];
		$txt60 = "\ndistrict:".$_SESSION['district'];
		$txt61 = "\npoliceStation:".$_SESSION['policeStation'];
		$txt62 = "\npostOffice:".$_SESSION['postOffice'];
		$txt63 = "\ncontactinformation:".$_SESSION['contactinformation'];
		$txt64 = "\nemail:".$_SESSION['email'];
		$txt65 = "\nrelationship:".$_SESSION['relationship'];
		
		$txt67="/n/n/n PaymentInformation";
		$txt68 = "/nPayment Type:".$_SESSION['paymenttype'];
		$txt69 = "/nCurrency:".$_SESSION['currency'];
		$txt70 = "/nAmount:".$_SESSION['amount'];
		$txt71 = "/nDate of Payment:".$_SESSION['paymentdate'];
		$txt72 = "/nReceipt No:".$_SESSION['receiptno'];
		$txt73 = "/nName of Bank:".$_SESSION['bank'];
		$txt74 = "/nName of Branch:".$_SESSION['branch'];
		
		fwrite($myfile, $txt0);
		fwrite($myfile, $txt1);
		fwrite($myfile, $txt2);
		fwrite($myfile, $txt3);
		fwrite($myfile, $txt4);
		fwrite($myfile, $txt5);
		fwrite($myfile, $txt6);
		fwrite($myfile, $txt7);
		fwrite($myfile, $txt8);
		fwrite($myfile, $txt9);
		fwrite($myfile, $txt10);
		fwrite($myfile, $txt11);
		fwrite($myfile, $txt12);
		fwrite($myfile, $txt13);
		fwrite($myfile, $txt14);
		fwrite($myfile, $txt15);
		fwrite($myfile, $txt16);
		fwrite($myfile, $txt17);
		fwrite($myfile, $txt18);
		fwrite($myfile, $txt19);
		fwrite($myfile, $txt20);
		fwrite($myfile, $txt21);
		fwrite($myfile, $txt22);
		fwrite($myfile, $txt23);
		fwrite($myfile, $txt24);
		fwrite($myfile, $txt25);
		fwrite($myfile, $txt26);
		fwrite($myfile, $txt27);
		
		fclose($myfile);
?>
