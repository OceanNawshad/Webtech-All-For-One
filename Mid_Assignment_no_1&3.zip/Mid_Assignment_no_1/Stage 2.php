<?php
	function sanitize_input($data)
	{
		$data=trim($data);
		$data=stripslashes($data);
		$data=htmlspecialchars($data);
		return $data;
		
	}
session_start();
	
	if(isset($_POST['save&continue']))
	{
		$_SESSION['country']=sanitize_input($_POST['country']);
		$_SESSION['dateofbirth']=sanitize_input($_POST['date']);
		$_SESSION['gender']=sanitize_input($_POST['gender']);
		$_SESSION['passporttype']=sanitize_input($_POST['passporttype']);
		$_SESSION['birthIdNo']=sanitize_input($_POST['birthIdNo']);
		$_SESSION['deliveryType']=sanitize_input($_POST['deliveryType']);
		$_SESSION['nationalIdNo']=sanitize_input($_POST['nationalIdNo']);
		$_SESSION['taxIdNo']=sanitize_input($_POST['taxIdNo']);
		$_SESSION['cm']=sanitize_input($_POST['cm']);
		$_SESSION['inch']=sanitize_input($_POST['inch']);
		$_SESSION['religion']=sanitize_input($_POST['religion']);
		$_SESSION['nameOfApplicant']=sanitize_input($_POST['nameOfApplicant']);
		$_SESSION['email']=sanitize_input($_POST['email']);
		$_SESSION['givenName']=sanitize_input($_POST['givenName']);
		$_SESSION['surname']=sanitize_input($_POST['surname']);
		$_SESSION['nationality']=sanitize_input($_POST['nationality']);
		$_SESSION['citizenshipstatus']=sanitize_input($_POST['citizenshipstatus']);
		$_SESSION['fathersName']=sanitize_input($_POST['fathersName']);
		$_SESSION['dualCitizenship']=sanitize_input($_POST['dualCitizenship']);
		$_SESSION['fathersnationality']=sanitize_input($_POST['fathersnationality']);
		$_SESSION['fathersprofession']=sanitize_input($_POST['fathersprofession']);
		$_SESSION['mothersName']=sanitize_input($_POST['mothersName']);
		$_SESSION['village/house']=sanitize_input($_POST['village/house']);
		$_SESSION['mothersnationality']=sanitize_input($_POST['mothersnationality']);
		$_SESSION['road/block/sector']=sanitize_input($_POST['road/block/sector']);
		$_SESSION['mothersprofession']=sanitize_input($_POST['mothersprofession']);
		$_SESSION['district']=sanitize_input($_POST['district']);
		$_SESSION['spousesName']=sanitize_input($_POST['spousesName']);
		$_SESSION['policeStation']=sanitize_input($_POST['policeStation']);
		$_SESSION['spousesNationality']=sanitize_input($_POST['spousesNationality']);
		$_SESSION['postOffice']=sanitize_input($_POST['postOffice']);
		$_SESSION['spousesProfession']=sanitize_input($_POST['spousesProfession']);
		$_SESSION['maritalStatus']=sanitize_input($_POST['maritalStatus']);
		$_SESSION['applicantsProfession']=sanitize_input($_POST['applicantsProfession']);
		$_SESSION['village/house']=sanitize_input($_POST['village/house']);
		$_SESSION['countryOfBirth']=sanitize_input($_POST['countryOfBirth']);
		$_SESSION['proad/block/sector']=sanitize_input($_POST['proad/block/sector']);
		$_SESSION['birthdistrict']=sanitize_input($_POST['birthdistrict']);
		$_SESSION['district']=sanitize_input($_POST['district']);
		$_SESSION['permanentpoliceStation']=sanitize_input($_POST['permanentpoliceStation']);
		$_SESSION['permanentpostoffice']=sanitize_input($_POST['permanentpostoffice']);
	}
	else
	{
		header("location:index.php");
	}
 
	
?>
<!doctype html>
<html>
	<head>
		<title>Passport Form stage 2</title>
	</head>
	<body>
		<h3>PASSPORT APPLICATION-stage-2</h3>
		<font color="green">Online Application Id: 0A0000004008216</font>
		</br>
		Fields marked with <font color="red"> (*) </font>are mandatory.
		<hr>
		
		<form name="stage2Form" method="post" action="Final Stage.php">
			<table align=left border=0>
				<tr>
					<td colspan=3><h4>Applicant Contact Information</h4></td>
					
					<td><pre>                                </pre></td>
					<td colspan=3><h4>Old Passport Information</h4></td>
				</tr>
				
				<tr>
					<td>Office No</td>
					<td>:</td>
					<td><input type="text" name="officeno" expression="[0-9]"></td>
					<td><pre>                                </pre></td>
					<td>Passport No</td>
					<td>:</td>
					<td> <input type="text" name="passportno" expression="[0-9]"></td>
					
				</tr>
				
				<tr>
					<td>Residence No</td>
					<td>:</td>
					<td><input type="text" name="residence no"></td>
					<td><pre>                                </pre></td>
					<td>Place of Issue</td>
					<td>:</td>
					<td> <input type="text" name="placeofissue" expression="[a-zA-Z]"></td>
					
				</tr>
				
				<tr>
					<td>Mobile No</td>
					<td>:</td>
					<td><input type="tel" name="mobileno"></td>
					<td><pre>                                </pre></td>
					<td>Date of Issue</td>
					<td>:</td>
					<td>  <input type="date" name="dateofissue"></td>
					
				</tr>
				
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td><pre>                                </pre></td>
					<td>Re Issue Reason</td>
					<td>:</td>
					<td>
						<input list="reissuereason" name="reissuereason" required>
						<datalist id="reissuereason">
						
							<option value="Lost"></option>
							<option value="Damaged"></option>
							<option value="Expired"></option>
							
						</datalist>	
					</td>
					
				</tr>
				
				<tr>
					<td colspan=3><h4>Applicant Contact Information</h4></td>
					
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td>Name</td>
					<td>:</td>
					<td><input type="text" name="name" required expression="[a-zA-Z]"></td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td>Country</td>
					<td>:</td>
					<td>
						<input list="country" name="country" required>
						<datalist id="country">
						
							<option value="Bangladesh"></option>
							<option value="India"></option>
							<option value="Pakistan"></option>
							
						</datalist>
					</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td><input type="checkbox" name="sameaspermanentaddress" value="sameaspermanentaddress">Same as Permanent Address<br></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td><input type="checkbox" name="sameaspresentaddress" value="sameaspresentaddress">Same as Permanent Address<br></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td>Village/House</td>
					<td>:</td>
					<td><input type="text" name="village/house" expression="[a-zA-Z0-9]"></td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td>Road/Block/Sector</td>
					<td>:</td>
					<td><input type="text" name="road/block/sector" expression="[a-zA-Z0-9]"></td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td>District</td>
					<td>:</td>
					<td>
						<input list="district" name="district" required>
						<datalist id="district">
							<option value="Dhaka"></option>
							<option value="Khulna"></option>
							<option value="Sylhet"></option>
							<option value="Chittagong"></option>
							<option value="Rajshahi"></option>
							<option value="Barisal"></option>
							<option value="Rangpur"></option>
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td>Police Station</td>
					<td>:</td>
					<td> <input type="text" name="policeStation" required expression="[a-zA-Z]"></td>
					</td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td>Post Office</td>
					<td>:</td>
					<td><input type="text" name="postOffice" required expression="[0-9]{4}"></td>
					</td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				
				
				<tr>
					<td>Contact Information</td>
					<td>:</td>
					<td><input type="tel" name="contactinformation" required></td>
					</td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td>Email</td>
					<td>:</td>
					<td><input type="email" name="email"></td>
					</td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td>Relation</td>
					<td>:</td>
					<td><input list="relationship" name="relationship">
						<datalist id="relationship">
							<option value="Single"></option>
							<option value="Married"></option>
						</datalist>
					</td>
					
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
				</tr>
				
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td><a href="index.php"><button type="button">Previous Page</button></a></td>
					<td></td>
					<td><input type="submit" name="submitstage2"  value="Save & Next"></td>
					
				</tr>
				
				
				
				
			</table>	
			
		</form>
		
		
		
	</body>
</html>