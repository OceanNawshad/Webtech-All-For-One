<html>
	<head>
		<title>Frequency Counter</title>
	</head>
	<body>
		</br>
		<h2><p align=center>Character Frequency Counter</p></h2>
		</br>
		<p align=center>Insert your string into the following text area to get the count per character</p>
		
		<form  name="frequencyCounter" method="post" action="page1.php" align="center" >
			<input type="text" name="textArea">
			</br>	
			<input type="submit" value="submit">
		</form>
	</body>
</html>