<html>
		<body>
			<?php
				$text=$_POST['textArea'];
	
				$mode2=count_chars($text,1);
				echo "<br>";
				foreach($mode2 as $k=>$v)
				{
					echo '<br>';
					echo '<br>';
					echo chr($k)." is ".$v."times";
	    
		
				}
				
				
				
				echo '<br>';
				echo '<br>';
				
				 print_r(array_count_values(str_word_count($text,1)));

				echo '<br>';
				
				
	
	
	
			?>
	</body>
</html>