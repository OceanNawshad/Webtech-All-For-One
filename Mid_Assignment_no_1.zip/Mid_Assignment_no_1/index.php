<?php
session_start(); 
?>

<html>
	<head>
		<title>Passport Security Information Form</title>
	</head>
	
	<body>
		<h3>PASSPORT APPLICATION-stage-1</h3>
		<font color="red">Before filling up the form read the </font> <u>Guidelines</u> <font color="red"> carefully. </font>
		</br>
		Fields marked with <font color="red"> (*) </font>are mandatory.
		<hr>
		
		<form name="stage1Form" method="post" action="Stage 2.php">
			<table align=left>
				<tr>
					<td colspan=7><h4>Passport Application Information</h4></td>
				</tr>	
				
				<tr>
					
					
					<td>Applying In</td>
					<td>:</td>
					<td>
						<input list="country" name="country" required>
						<datalist id="country">
						
							<option value="Bangladesh">Bangladesh</option>
							<option value="India">India</option>
							<option value="Pakistan">Pakistan</option>
							<option value="Nepal">Nepal</option>
						</datalist>	
						
					</td>
					
					<td><pre>                                </pre></td>
					<td>Date of Birth</td>
					<td> : </td>
					<td><input type="date" name="date" required></td>
					
				</tr>
				
				<tr>
					
					<td>Application Type</td>
					<td>:</td>
					<td><b>NEW APPLICATION</b></td>
					<td><pre>                                </pre></td>
					<td>Gender</td>
					<td>:</td>
					<td>
						<input type="radio" name="gender" value="male" checked> Male<br>
						<input type="radio" name="gender" value="female"> Female<br>
						<input type="radio" name="gender" value="other"> Other
						
						
					</td>
					
				</tr>
				
				<tr>
					<td>Passport Type</td>
					<td>:</td>
					<td><input list="passportType" name="passporttype" required>
						<datalist id="passportType">
						
							<option value="ORDINARY"></option>
							<option value="DIPLOMATIC"></option>
							<option value="OFFICIAL"></option>
							
						</datalist>	
					</td>
					<td><pre>                                </pre></td>
					<td>Birth Id no</td>
					<td>:</td>
					<td><input type="text" name="birthIdNo" required expression="[a-zA-Z]"></td>
					
				</tr>
				
				<tr>
					<td>Delivery Type</td>
					<td>:</td>
					<td>
						<input type="radio" name="deliveryType" value="Regular" checked>Regular<br>
						<input type="radio" name="deliveryType" value="Express">Express<br>
					</td>
					<td><pre>                                </pre></td>
					<td>National Id No</td>
					<td>:</td>
					<td><input type="text" name="nationalIdNo" required expression="[0-9]"></td>

					
				</tr>
				
				<tr>
					<td colspan="3"></td>
					<td><pre>                                </pre></td>
					<td>Tax Id No</td>
					<td>:</td>
					<td><input type="text" name="taxIdNo" expression="[0-9]"></td>
					
					
				</tr>
				
				<tr>
					<td colspan="3"></td>
					<td><pre>                                </pre></td>
					<td>Height</td>
					<td>:</td>
					<td><input type="text" name="cm" style="width: 50px" required expression="[0-9]">cm<input type="text" name="inch" style="width:50px" required expression="[0-9]">inch</td>
					
				</tr>
				
				<tr>
					<td><h4><br>Personal Information</h4></td>
					<td></td>
					<td></td>
					<td><pre>                                </pre></td>
					<td>Religion</td>
					<td>:</td>
					<td>
						<input list="religion" name="religion" required>
						<datalist id="religion">
						
							<option value="Islam"></option>
							<option value="Hindu"></option>
							<option value="Christian"></option>
							
						</datalist>	
					</td>
					
				</tr>
				
				<tr>
					<td>Name of Applicant</td>
					<td>:</td>
					<td><input type="text" name="nameOfApplicant" required expression="[a-zA-Z0-9]"></td>
					<td><pre>                                </pre></td>
					<td>Email</td>
					<td>:</td>
					<td> <input type="email" name="email">required</td>
					
				</tr>
				
				<tr>
					<td>First Part<br>(Given Name)</td>
					<td>:</td>
					<td><input type="text" name="givenName" expression="[a-zA-Z]"></td>
					<td><pre>                                </pre></td>
					<td colspan="3"><h4><br>Citizenship Information</h4></td>
					
				</tr>
				
				<tr>
					<td>Second part<br>(Surname)</td>
					<td>:</td>
					<td><input type="text" name="surname" required expression="[a-zA-Z]"></td>
					<td><pre>                                </pre></td>
					<td>Nationality</td>
					<td>:</td>
					<td>
						<input list="nationality" name="nationality" required>
						<datalist id="nationality">
						
							<option value="Bangladeshi">Bangladesh</option>
							<option value="Indian">India</option>
							<option value="Pakistani">Pakistan</option>
							<option value="Nepali">Nepal</option>
						</datalist>	
					</td>
					
					
				</tr>
				
				<tr>
					<td colspan="3">Guadrian<input type="checkbox" name="guradian"><font color="red">"tick"</font> only if Applicant is legally adopted<br></td>
					<td><pre>                                </pre></td>
					<td>Citizenship Status</td>
					<td>:</td>
					<td><input list="citizenshipStatus" name="citizenshipstatus">
						<datalist id="citizenshipStatus">
							<option value="Birth"></option>
							<option value="Migration"></option>
							<option value="others"></option>
							
						</datalist>
					
					</td>
				</tr>
				
				<tr>
					<td>Father's Name</td>
					<td>:</td>
					<td><input type="text" name="fathersName" required expression="[a-zA-Z0-9]"></td>
					<td><pre>                                </pre></td>
					<td>Dual Citizenship</td>
					<td>:</td>
					<td><input type="radio" name="dualCitizenship" value="Yes" checked required>Yes<br>
						<input type="radio" name="dualCitizenship" value="No" required>No<br>
					</td>	
				</tr>
				
				<tr>
					<td>Father's Nationality</td>
					<td>:</td>
					<td><input list="fathersNationality" name="fathersnationality">
						<datalist id="fathersNationality">
							<option value="Bangladeshi"></option>
							<option value="Indian"></option>
							<option value="Pakistani"></option>
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td colspan="3"><h4><br>Present Address</h4></td>
					
				</tr>
				
				<tr>
					<td>Father's Profession</td>
					<td>:</td>
					<td><input list="fathersProfession" name="fathersprofession" required>
						<datalist id="fathersProfession">
							<option value="Banker"></option>
							<option value="Govt Job"></option>
							<option value="Others"></option>
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
					
				</tr>
				
				<tr>
					<td>Mother's Name</td>
					<td>:</td>
					<td><input type="text" name="mothersName" required expression="[a-zA-Z]"></td>
					<td><pre>                                </pre></td>
					<td>village/House</td>
					<td>:</td>
					<td> <input type="text" name="village/house" required></td>
					
				</tr>
				
				<tr>
					<td>mothers's Nationality</td>
					<td>:</td>
					<td><input list="mothersNationality" name="mothersnationality" required>
						<datalist id="mothersNationality">
							<option value="Bangladeshi"></option>
							<option value="Indian"></option>
							<option value="Pakistani"></option>
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td>Road/Block/Sector</td>
					<td>:</td>
					<td><input type="text" name="road/block/sector"></td>
					
					
				</tr>
				
				<tr>
					<td>mothers's Profession</td>
					<td>:</td>
					<td><input list="mothersProfession" name="mothersprofession" required>
						<datalist id="mothersProfession">
							<option value="Banker"></option>
							<option value="Govt Job"></option>
							<option value="Others"></option>
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td>District</td>
					<td>:</td>
					<td>
						<input list="district" name="district" required>
						<datalist id="district">
							<option value="Dhaka"></option>
							<option value="Khulna"></option>
							<option value="Sylhet"></option>
							<option value="Chittagong"></option>
							<option value="Rajshahi"></option>
							<option value="Barisal"></option>
							<option value="Rangpur"></option>
							
						</datalist>
					</td>
					
					
				</tr>
				
				<tr>
					<td>Spouse's Name</td>
					<td>:</td>
					<td><input type="text" name="spousesName" expression="[a-zA-Z]"></td>
					<td><pre>                                </pre></td>
					<td>Police Station</td>
					<td>:</td>
					<td> <input type="text" name="policeStation" required expression="[a-zA-Z]"></td>
					
				</tr>
				
				<tr>
					<td>spouses's Nationality</td>
					<td>:</td>
					<td><input list="spousesNationality" name="spousesNationality">
						<datalist id="spousesNationality">
							<option value="Bangladeshi"></option>
							<option value="Indian"></option>
							<option value="Pakistani"></option>
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td>Post Office</td>
					<td>:</td>
					<td><input type="text" name="postOffice" required expression="[0-9]{4}"></td>
					
					
				</tr>
				
				<tr>
					<td>spouses's Profession</td>
					<td>:</td>
					<td><input list="spousesProfession" name="spousesProfession">
						<datalist id="spousesProfession">
							<option value="Banker"></option>
							<option value="Govt Job"></option>
							<option value="Others"></option>
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td colspan="3"><h4><br>Permanent Address</h4></td>
					
					
				</tr>
				
				<tr>
					<td>Marital Status</td>
					<td>:</td>
					<td><input list="maritalStatus" name="maritalStatus">
						<datalist id="maritalStatus">
							<option value="single"></option>
							<option value="Married"></option>
							
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
					
					
				</tr>
				
				<tr>
					<td>Applicant's Profession</td>
					<td>:</td>
					<td><input list="applicantsProfession" name="applicantsProfession" required>
						<datalist id="applicantsProfession">
							<option value="Banker"></option>
							<option value="Govt Job"></option>
							<option value="Others"></option>
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td>village/House</td>
					<td>:</td>
					<td> <input type="text" name="village/house" required expression="[a-zA-Z]"></td>
					
					
					
				</tr>
				
				<tr>
					<td>Counrty of Birth</td>
					<td>:</td>
					<td><input list="countryOfBirth" name="countryOfBirth" required>
						<datalist id="countryOfBirth">
							<option value="Bangladesh"></option>
							<option value="Pakistan"></option>
							<option value="India"></option>
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td>Road/Block/Sector</td>
					<td>:</td>
					<td><input type="text" name="proad/block/sector"></td>
					
					
					
					
				</tr>
				
				<tr>
					<td>Birth District</td>
					<td>:</td>
					<td>
						<input list="birthdistrict" name="birthdistrict" required>
						<datalist id="birthdistrict">
							<option value="Dhaka"></option>
							<option value="Khulna"></option>
							<option value="Sylhet"></option>
							<option value="Chittagong"></option>
							<option value="Rajshahi"></option>
							<option value="Barisal"></option>
							<option value="Rangpur"></option>
							
						</datalist>
					</td>
					<td><pre>                                </pre></td>
					<td>District</td>
					<td>:</td>
					<td>
						<input list="pdistrict" name="district">
						<datalist id="pdistrict">
							<option value="Dhaka"></option>
							<option value="Khulna"></option>
							<option value="Sylhet"></option>
							<option value="Chittagong"></option>
							<option value="Rajshahi"></option>
							<option value="Barisal"></option>
							<option value="Rangpur"></option>
							
						</datalist>
					</td>
					
				</tr>
				
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td><pre>                                </pre></td>
					<td>Police Station</td>
					<td>:</td>
					<td> <input type="text" name="permanentpoliceStation" required expression="[a-zA-Z]"></td>
				</tr>
				
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td><pre>                                </pre></td>
					<td>Post Office</td>
					<td>:</td>
					<td> <input type="text" name="permanentpostoffice" required expression="[0-9]{4}"></td>
				</tr>
				
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td><pre>                                </pre></td>
					<td><br><input type="reset" value="Reset"></td>
					<td></td>
					<td><br><input type="submit" name="save&continue" value="save & Continue"></td>
				</tr>
				
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td><pre>                                </pre></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				
				
				
				
				
				
			</table>
			
			
			
			
					
			
			
					
					
				
			
			
			
			
			
		
		
		
		
		</form>
	</body>



</html>