

<?php
echo file_get_contents("newfile.txt");
?>
