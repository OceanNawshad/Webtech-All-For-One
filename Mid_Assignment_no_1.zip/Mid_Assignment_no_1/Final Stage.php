<?php
	function sanitize_input($data)
	{
		$data=trim($data);
		$data=stripslashes($data);
		$data=htmlspecialchars($data);
		return $data;
		
	}
session_start();
	
	if(isset($_POST['submitstage2']))
	{
		$_SESSION['random']=sanitize_input($_POST['random']);
		$_SESSION['officeno']=sanitize_input($_POST['officeno']);
		$_SESSION['passportno']=sanitize_input($_POST['passportno']);
		$_SESSION['residence']=sanitize_input($_POST['residence']);
		$_SESSION['placeofissue']=sanitize_input($_POST['placeofissue']);
		$_SESSION['mobileno']=sanitize_input($_POST['mobileno']);
		$_SESSION['dateofissue']=sanitize_input($_POST['dateofissue']);
		$_SESSION['reissuereason']=sanitize_input($_POST['reissuereason']);
		$_SESSION['name']=sanitize_input($_POST['name']);
		$_SESSION['country']=sanitize_input($_POST['country']);
		$_SESSION['village/house']=sanitize_input($_POST['village/house']);
		$_SESSION['road/block/sector']=sanitize_input($_POST['road/block/sector']);
		$_SESSION['district']=sanitize_input($_POST['district']);
		$_SESSION['policeStation']=sanitize_input($_POST['policeStation']);
		$_SESSION['postOffice']=sanitize_input($_POST['postOffice']);
		$_SESSION['contactinformation']=sanitize_input($_POST['contactinformation']);
		$_SESSION['email']=sanitize_input($_POST['email']);
		$_SESSION['relationship']=sanitize_input($_POST['relationship']);
		
		
	}
	else
	{
		header("location:index.php");
	}
 
	
?>

<html>
	<head>
		<title>Passport Form stage 3</title>
	</head>
	<body>
		<h3>PASSPORT APPLICATION-stage-2</h3>
		<font color="green">Online Application Id: 0A0000004008216</font>
		</br>
		Fields marked with <font color="red"> (*) </font>are mandatory.
		<hr>
		
		<form name="stage2Form" method="post" action="page4.php">
			<table align=left border=0>
				<tr>
					<td colspan=3><h4>Payment Information</h4></td>
					
					<td><pre>                                </pre></td>
				</tr>
				
				<tr>
					<td>Payment Type</td>
					<td>:</td>
					<td><input type="radio" name="paymenttype" value="online" checked>Online<br>
						<input type="radio" name="paymenttype" value="offline" required>Offline<br>
					</td>	
				</tr>
				
				<tr>
					
					<td><br><input type="checkbox" name="skippayment" value="skippayment">Skip Payment<br></td>
				</tr>
				
				<tr>
					<td>Amount</td>
					<td>:</td>
					<td><input list="currency" name="currency" required>
						<datalist id="currency">
							<option value="BDT"></option>
							<option value="US Dollar"></option>
						</datalist>
					</td>
					<td><input type="text" name="amount" required expression="[0-9]"></td>
					
					
					
				</tr>
				
				<tr>
					<td>Date of Payment</td>
					<td>:</td>
					
					<td><input type="date" name="paymentdate" required"></td>
					
					
					
				</tr>
				
				<tr>
					<td>Receipt No</td>
					<td>:</td>
					
					<td><input type="text" name="receiptno" required expression="[0-9]"></td>
					
					
					
				</tr>
				
				<tr>
					<td>Name of Bank</td>
					<td>:</td>
					<td><input list="bank" name="bank">
						<datalist id="bank">
							<option value="Agrani"></option>
							<option value="DBBL"></option>
						</datalist>
					</td>
					
					
					
					
				</tr>
				
				<tr>
					<td>Name of Branch</td>
					<td>:</td>
					<td><input type="text" name="branch" expression="[a-zA-Z]"></td>
					
					
					
					
				</tr>
				
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td><input type="submit" name="save&Next" value="save & Next"></td>
					
					
					
					
				</tr>
				
				
			
			</table>
			
		</form>	
	</body>
</html>	